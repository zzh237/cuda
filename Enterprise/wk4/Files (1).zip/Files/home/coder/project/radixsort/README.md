### [radix_sort: benchmarking the CUB radix sort](app_radix_sort)
This application benchmarks the CUB radix sort implementation with all possible combinations
of key/value lengths and allow user to select size of the array to sort.
