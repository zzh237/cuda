# "Generic Bubble Sort"

> A single block generic parallel bubble sort implementation (CUDA)

## Compile

    # run from repo dir
    nvcc -o out/generic-bubble-sort generic-bubble-sort.cu   

## Approach

To know how this implementation works, check [this answer](https://stackoverflow.com/a/63567939/3503855) posted on stackoverflow.

***Initial Code can be found at https://github.com/Bulat-Ziganshin/Compression-Research***