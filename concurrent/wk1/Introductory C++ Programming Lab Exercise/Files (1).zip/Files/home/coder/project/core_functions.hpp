#include <string>
using namespace std;

void printMessage(string text);
bool verifyUser(std::string username);