make clean build

USERNAME=$1

make run ARGS="$USERNAME"