Based on GitHub gist from https://gist.githubusercontent.com/ictlyh/f8473ad0cb1008c6b32c41f3dea98ef5/raw/f868c61fb55aa3c6f2835121c9f55d170149bc17/producer-consumer,
this code will demonstrate a working producer-consumer algorithm.

1. You can modify the code to see what the effect will be.
2. execute ```make clean build run```, which will clean, build, and then execute this solution.