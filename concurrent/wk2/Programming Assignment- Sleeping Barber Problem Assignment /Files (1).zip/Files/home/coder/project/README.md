## Activity description
The student will not need to develop any code for this assignment, but instead will execute the Sleeping Barbers code.

## Assignment Instructions
1. C​hange current directory to sleeping_barber
2. M​odify the code as you see fit (it is currently written as the solution for the problem, which is based on code from https://github.com/Nohclu/Sleeping-Barber-Python-3.6-/blob/master/barber.py
3. R​un the code via python3 sleeping_barber.py