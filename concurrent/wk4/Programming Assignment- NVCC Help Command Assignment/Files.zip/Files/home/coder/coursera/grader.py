#!/usr/bin/python3

# ENTRYPOINT for Dockerfile

# Dependencies
import logging
import os
from util import print_stderr, send_feedback, print_stdout
import re

nvcc_usage_help_regex_string = "^Usage.*nvcc.*options.*inputfile.*$"


def main(filename):
    # Find the learner's submission  ----------------------------------------------
    project_location = "/shared/submission/"

    # Each partId is evaluated one at a time; thus, only one submission file will be stored
    # at a time in the /shared/submission/ directory.
    learner_file = filename
    # Open file for reading
    fo = open(project_location + learner_file)
    # Read the first line from the file
    line = fo.readline()
    found = False
    
    # Loop until EOF
    while line != '':
        found = found or re.search("^Usage.*nvcc.*options.*inputfile.*$", line)
        # Read next line
        line = fo.readline()

    fo.close()

    # Perform grading
    if found:
        feedback = "nvcc help command output was found."
        final_fractional_score = 1.0
    else:
        feedback = f"The output for the nvcc help command was not found, you should execute something like 'nvcc -h "
        final_fractional_score = 0.0

    # Close the files

    feedback = f"{feedback} Your grade will be {final_fractional_score*100}"

    send_feedback(final_fractional_score, feedback)


if __name__ == '__main__':
    try:
        filename = os.environ['filename']
        main(filename=filename)
    except Exception as e:
        print_stderr("Please provide the submission file.")
