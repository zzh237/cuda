#!/usr/bin/python3

# ENTRYPOINT for Dockerfile

# Dependencies
import logging
import os
from util import print_stderr, send_feedback, print_stdout
import re

nvcc_driver_api_output_first_line_regex = "^.*Initializing.*$"
nvcc_driver_api_output_last_line_regex = "^.*Finalizing.*$"
nvcc_runtime_api_output_first_line_regex = "^.*Vector addition.*$"
nvcc_runtime_api_output_last_line_regex = "^.*Done.*$"


def main(part_id, filename):
    # Find the learner's submission  ----------------------------------------------
    
    project_location = "/shared/submission/"
    
    # Each partId is evaluated one at a time; thus, only one submission file will be stored
    # at a time in the /shared/submission/ directory.
    file_location = project_location + filename
    feedback = f"Processing part: {part_id} with file: {file_location}.\n"
    
    if 'driver-api' in part_id:
        (score, feedback) = driver_api_test(part_id, file_location, feedback)
    elif 'runtime-api' in part_id:
        (score, feedback) = runtime_api_test(part_id, file_location, feedback)
    
    feedback = f"{feedback}Your grade will be {score * 100}.\n"
    send_feedback(score, feedback)


def use_regex_on_file(file_location, regex_string):
    # Open file for reading
    fo = open(file_location)
    # Read the first line from the file
    line = fo.readline()
    found = False
    
    # Loop until EOF
    while line != '':
        found = found or re.search(regex_string, line)
        # Read next line
        line = fo.readline()
    
    fo.close()
    score = 1.0 if found else 0
    return found, score


def driver_api_test(part_id, file_location, feedback):
    first_found, first_score = use_regex_on_file(file_location=file_location,
                                                 regex_string=nvcc_driver_api_output_first_line_regex)
    last_found, last_score = use_regex_on_file(file_location=file_location,
                                               regex_string=nvcc_driver_api_output_last_line_regex)
    score = (first_score + last_score) / 2
    # Perform grading
    if score == 1:
        feedback = f"Driver API part: {part_id} content was fully found.\n"
    else:
        if not first_found:
            feedback = f"{feedback}The expected Initializing line in the driver api in part was not found.\n"
        if not last_found:
            feedback = f"{feedback}The expected Initializing line in the driver api in part was not found.\n"
        feedback = f"{feedback}The output for {part_id} was not found, refer to the README.md file to understand the commands to execute.\n"
    
    found = first_found and last_found
    return found, feedback

def runtime_api_test(part_id, file_location, feedback):
    first_found, first_score = use_regex_on_file(file_location=file_location,
                                                 regex_string=nvcc_runtime_api_output_first_line_regex)
    last_found, last_score = use_regex_on_file(file_location=file_location,
                                                regex_string=nvcc_runtime_api_output_last_line_regex)
    score = (first_score + last_score) / 2
    # Perform grading
    if score == 1:
        feedback = f"Runtime API part: {part_id} content was fully found.\n"
    else:
        if first_found == 0:
            feedback = f"{feedback}The expected Initializing line in the runtime api in part was not found.\n"
        if last_found == 0:
            feedback = f"{feedback}The expected Initializing line in the runtime api in part was not found.\n" \
        feedback = f"{feedback}The output for {part_id} was not found, refer to the README.md file to understand the commands to execute.\n"
    found = first_found and last_found
    return found, feedback

if __name__ == '__main__':
    try:
        part_id = os.environ['partId']
        filename = os.environ['filename']
    except Exception as e:
        print_stderr("Please provide the part_id.")
        send_feedback(0.0, "Please provide the part_id.")
    else:
        main(part_id=part_id, filename=filename)
