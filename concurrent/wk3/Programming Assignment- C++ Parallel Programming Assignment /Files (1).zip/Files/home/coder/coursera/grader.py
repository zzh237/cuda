#!/usr/bin/python3

# ENTRYPOINT for Dockerfile

# Dependencies
import logging
import os
from pydash import filter_
from util import print_stderr, send_feedback, print_stdout

part_id_num_threads_map = {'uSrKD': 1, 'T9bcV': 3, 'OISFH': 20}

OUTPUT_START_THREAD_PREFIX = "C++11: Thread retrieved ticket number: "
OUTPUT_START_THREAD_SUFFIX = " started."
OUTPUT_COMPLETED_THREAD_PREFIX = "C++11: Thread with ticket number: "
OUTPUT_COMPLETED_THREAD_SUFFIX = " completed."


def retrieve_thread_info_from_output(output_string, prefix, suffix) -> int:
    print_stdout(
        f"output string: {output_string.rstrip()} prefix: {prefix} suffix: {suffix}")
    thread_index_str = output_string.replace(prefix, '') \
        .replace(suffix, '').replace(" ", '')
    print_stdout(f"thread index: {thread_index_str}")
    return int(thread_index_str)


def main(part_id, filename):
    print_stderr("main: " + part_id)
    # Find the learner's submission  ----------------------------------------------
    project_location = "./"

    # Each partId is evaluated one at a time; thus, only one submission file will be stored
    # at a time in the /shared/submission/ directory.
    learner_file = filename
    # Open file for reading
    fo = open(project_location + learner_file)
    # Read the first line from the file
    line = fo.readline().rstrip()
    num_threads = part_id_num_threads_map[part_id]
    started_threads = []
    completed_threads = []
    for _ in range(num_threads):
        started_threads.append("")
        completed_threads.append("")
    # Loop until EOF
    while line != '':
        if line.startswith(OUTPUT_START_THREAD_PREFIX):
            thread_index = retrieve_thread_info_from_output(
                line, OUTPUT_START_THREAD_PREFIX, OUTPUT_START_THREAD_SUFFIX)
            started_threads[thread_index] = line
        elif line.startswith(OUTPUT_COMPLETED_THREAD_PREFIX):
            thread_index = retrieve_thread_info_from_output(
                line, OUTPUT_COMPLETED_THREAD_PREFIX,
                OUTPUT_COMPLETED_THREAD_SUFFIX)
            completed_threads[thread_index] = line
        # Read next line
        line = fo.readline()

    # Filter out unused thread indexes from start and completed count
    started_threads = filter_(started_threads, lambda x: x is not "")
    completed_threads = filter_(completed_threads, lambda x: x is not "")

    num_started_threads = len(started_threads)
    num_completed_threads = len(completed_threads)

    # Perform grading
    if num_started_threads == num_completed_threads:
        feedback = "All started threads were completed."
        if num_completed_threads < num_threads:
            feedback = f"{feedback} The number of started threads({num_started_threads}) is less than the expected " \
                f"number({num_threads})."
            final_fractional_score = num_completed_threads / float(num_threads)
        else:
            feedback = f"{feedback} All configured threads were started and completed."
            final_fractional_score = 1.0
    else:
        feedback = f"Not all started threads ({num_threads}) completed ({num_completed_threads})."
        final_fractional_score = 0.5

    # Close the files
    fo.close()
    if feedback is None:
        feedback = "Your code and associated files did not complete compiling and execution."

    feedback = f"{feedback} Your grade will be {final_fractional_score*100}% of this part's grade"

    send_feedback(final_fractional_score, feedback)

if __name__ == '__main__':
    try:
        part_id = os.environ['partId']
        filename = os.environ['filename']
    except Exception as e:
        print_stderr("Please provide the part_id.")
        send_feedback(0.0, "Please provide the part_id.")
    else:
        main(part_id=part_id, filename=filename)
