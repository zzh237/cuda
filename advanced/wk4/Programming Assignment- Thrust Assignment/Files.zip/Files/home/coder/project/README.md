Sample: boxFilterNPP
Minimum spec: SM 2.0

A NPP CUDA Sample that demonstrates how to use NPP FilterBox function to perform a Box Filter.

Key concepts:
Performance Strategies
Image Processing
NPP Library