#!/usr/bin/env bash
make clean build

make run > output.txt