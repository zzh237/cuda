#!/usr/bin/python3

# ENTRYPOINT for Dockerfile

# Dependencies
import logging
import os
from util import print_stderr, send_feedback, print_stdout
import re
import sys

parsing_regex = "^.*Parsing CLI arguments.*$"
arguments_regex = "^.*inputImage:.*outputImage:.*currentPartId:.*threadsPerBlock:.*$"
reading_image_regex = "^.*Reading Image From File.*$"
rows_cols_regex = "^.*Rows:.*Columns:.*$"
kernel_execution_regex = "^.*Executing kernel.*$"
cleaning_device_regex = "^.*Cleaning CUDA device.*$"
cpu_conversion_regex = "^.*CPU applying kernel.*$"
comparison_regex = "^.*Comparing actual and test pixel arrays.*$"
differences_regex = "^.*meanImagePixelDifference:.*scaledMeanDifferencePercentage:.*$"
mean_difference_regex = "^.*Mean difference percentage:.*$"
minimum_expected_output_lines = 13


def main(part_id, filename):
	# Find the learner's submission  ----------------------------------------------
	project_location = "/shared/submission/"
	
	# Each partId is evaluated one at a time; thus, only one submission file will be stored
	# at a time in the /shared/submission/ directory.
	file_location = project_location + filename
	
	feedback = f"Processing part: {part_id} with file: {file_location}.\n"

	score, feedback = use_regex_on_file(file_location=file_location, feedback=feedback)
	
	feedback = f"{feedback}Your grade will be {score * 100}.\n"
	send_feedback(score, feedback)


def use_regex_on_file(file_location, feedback):
	# Open file for reading
	fo = open(file_location)
	# Read the first line from the file
	line = fo.readline()
	expected_output_lines = 0
	score = 0
	try:
		mean_difference_percentage = None
		# Loop until EOF
		while line != '':

			if re.search(parsing_regex, line):
				expected_output_lines += 1
			elif re.search(arguments_regex, line):
				expected_output_lines += 1
			elif re.search(reading_image_regex, line):
				expected_output_lines += 1
			elif re.search(rows_cols_regex, line):
				expected_output_lines += 1
			elif re.search(device_memory_allocation_regex, line):
				expected_output_lines += 1
			elif re.search(copy_host_to_device_regex, line):
				expected_output_lines += 1
			elif re.search(kernel_execution_regex, line):
				expected_output_lines += 1
			elif re.search(copy_device_to_host_regex, line):
				expected_output_lines += 1
			elif re.search(cleaning_device_regex, line):
				expected_output_lines += 1
			elif re.search(cpu_conversion_regex, line):
				expected_output_lines += 1
			elif re.search(comparison_regex, line):
				expected_output_lines += 1
			elif re.search(differences_regex, line):
				expected_output_lines += 1
			elif re.search(mean_difference_regex, line):
				expected_output_lines += 1
				mean_difference_array = line.split(' ')
				mean_difference_percentage = float(mean_difference_array[3])
			line = fo.readline()
		if expected_output_lines != minimum_expected_output_lines:
			feedback = f"{feedback}You have altered the included output text from the base assignment code. Please add any lines that you previously removed.\n"
			score = 0.0
		else:
			feedback = f"{feedback}Your code has been successfully submitted and your output included the minimum print statements.\n"
			if mean_difference_percentage > 25.0:
				score = 0.5
			elif mean_difference_percentage > 20.0:
				score = 0.75
			elif mean_difference_percentage > 15.0:
				score = 0.8
			elif mean_difference_percentage > 5.0:
				score = 0.9
			elif mean_difference_percentage > 2.5:
				score = 0.95
			elif mean_difference_percentage >= 0:
				score = 1
	except os.error as e:
		feedback = f"{feedback}An exception occured while parsing the output of convertRGBToGrey.exe.{sys.exc_info()[1]}\n" 
	
	print("score: ", score)

	fo.close()
	return score, feedback


if __name__ == '__main__':
	try:
		part_id = os.environ['partId']
		filename = os.environ['filename']
	except Exception as e:
		print_stderr("Please provide the part_id.")
		send_feedback(0.0, "Please provide the part_id.")
	else:
		main(part_id=part_id, filename=filename)
