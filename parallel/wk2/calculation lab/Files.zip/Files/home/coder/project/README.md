# Laboratory Activity Instructions

1. Develop calculation code inside of calculation kernel in calculation.cu.
2. Run make clean build
3. Execute code via ./calculation.exe

Feel free to modify all of the code as you wish, but this may affect your ability to run the make build target.
