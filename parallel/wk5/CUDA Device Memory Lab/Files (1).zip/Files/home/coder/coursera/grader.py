#!/usr/bin/python3

# ENTRYPOINT for Dockerfile

# Dependencies
import logging
import math
import os
from util import print_stderr, send_feedback, print_stdout
import re

cuda_math_op_regex = "^.*global.*$"

elements_per_thread_values = [1, 2, 4, 8, 16, 32, 64]
iterations = [1, 2, 3, 4, 5, 6, 7, 8]
kernels = ["global","constant","shared","register"]
total_iterations = len(elements_per_thread_values) * len(iterations) * len(kernels)

def main(part_id, filename):
    # Find the learner's submission  ----------------------------------------------
    project_location = "/shared/submission/"

    # Each partId is evaluated one at a time; thus, only one submission file will be stored
    # at a time in the /shared/submission/ directory.
    file_location = project_location + filename

    feedback = f"Processing part: {part_id} with file: {file_location}.\n"

    score, feedback = grade_assignment(part_id=part_id, file_location=file_location, feedback=feedback)

    feedback = f"{feedback}Your grade will be {score * 100}.\n"
    send_feedback(score, feedback)


def grade_assignment(part_id, file_location, feedback):
    # Open file for reading
    fo = open(file_location)
    part_id_str = None
    score = 0.5
    iteration_value = 0.5 / total_iterations

    all_line_parts = {}
    for kernel in kernels:
        elements_iterations = {}
        for elements_per_thread_value in elements_per_thread_values:
            elements_iterations[elements_per_thread_value] = 0
        all_line_parts[kernel] = elements_iterations
    line = fo.readline()
    try:
        # Loop until EOF
        while line != '':
            line = line.strip()
            line_parts = line.split(' ')
            if len(line_parts) > 8:
                kernel_val = line_parts[8]
                threads = line_parts[6]
                elements_per_thread_val = int(line_parts[4])
                all_line_parts[kernel_val][elements_per_thread_val] += 1
            line = fo.readline()
        for kernel in kernels:
            for elements_per_thread in elements_per_thread_values:
                for iteration in iterations:
                    if iteration < all_line_parts[kernel][elements_per_thread]:
                        score += iteration_value
        else:
            if score == 1.0:
                feedback = f"{feedback}For submission part with id: {part_id} all device memory kernels were run. " \
                           f"Good Job!\n"
            else:
                feedback = f"{feedback}For submission part with id: {part_id} not all device memory kernels and " \
                           f"iterations were executed successfully.\n"
    except os.error:
        feedback = f"{feedback}An exception occurred while parsing the output of your executable, look at the " \
                   f"assignment's output.txt file and ensure that you haven't modified it or the program ran " \
                   f"completely.\n"

    print("score: ", score)

    fo.close()
    return score, feedback


if __name__ == '__main__':
    try:
        part_id = os.environ['partId']
        filename = os.environ['filename']
    except Exception as e:
        print_stderr("Please provide the part_id.")
        send_feedback(0.0, "Please provide the part_id.")
    else:
        main(part_id=part_id, filename=filename)
