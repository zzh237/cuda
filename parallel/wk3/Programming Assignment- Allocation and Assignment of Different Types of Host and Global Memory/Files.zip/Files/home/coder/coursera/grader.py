#!/usr/bin/python3

# ENTRYPOINT for Dockerfile

# Dependencies
import logging
import math
import os
from util import print_stderr, send_feedback, print_stdout
import re

cuda_math_op_regex = "^.*Mathematical Operation:.*$"
cuda_part_id_regex = "^.*PartID:.*$"
cuda_input_a_regex = "^.*Input A:.*$"
cuda_input_b_regex = "^.*Input B:.*$"
cuda_result_regex = "^.*Result:.*$"

def main(part_id, filename):
    # Find the learner's submission  ----------------------------------------------
    project_location = "/shared/submission/"

    # Each partId is evaluated one at a time; thus, only one submission file will be stored
    # at a time in the /shared/submission/ directory.
    file_location = project_location + filename

    feedback = f"Processing part: {part_id} with file: {file_location}.\n"

    score, feedback = use_regex_on_file(
        part_id=part_id, file_location=file_location, feedback=feedback)

    feedback = f"{feedback}Your grade will be {score * 100}.\n"
    send_feedback(score, feedback)


def use_regex_on_file(part_id, file_location, feedback):
    # Open file for reading
    fo = open(file_location)
    math_op = None
    part_id_str = None
    input_a = []
    input_b = []
    result = []
    line = fo.readline()
    score = 0.0

    try:
        # Loop until EOF
        while line != '':
            line = line.strip()
            feedback = f"{feedback}line: {line}\n"
            line0 = line.split(' ')
            if re.search(cuda_math_op_regex, line):
                math_op = line0[2]
                feedback = f"{feedback}math_op: {math_op}\n"
            elif re.search(cuda_part_id_regex, line):
                part_id_str = line0[1]
            elif re.search(cuda_input_a_regex, line):
                input_a = line0[2:]
            elif re.search(cuda_input_b_regex, line):
                input_b = line0[2:]
            elif re.search(cuda_result_regex, line):
                result = line0[1:]
            line = fo.readline()
        if part_id != part_id_str:
            feedback=f"{feedback}Expected part id: {part_id} actual part id: {part_id_str} \n"
            feedback = f"{feedback}The output part id for the execution of your code does not match the part id of the submission, " \
                    "please ensure that you haven't modified the program output or run.sh\n"
        else:
            if part_id == "avffI" or part_id == "pOwge":
                score = 1.0
                feedback = f"{feedback}It appears that the broken program has been fixed. Good Job!\n"
            else:
                if part_id == "IYn5V" or part_id == "kWuuk":
                    math_op = "div"
                score = 1.0
                error_penalty = 1.0/len(input_a)
                for a, b, r in zip(input_a, input_b, result):
                    if part_id == "ZafI7" or part_id == "Tg70w":
                        a = int(a)
                        b = int(b)
                        r = int(r)
                    elif part_id == "IYn5V" or part_id == "kWuuk":
                        a = float(a)
                        b = float(b)
                        r = float(r)
                    e = None
                    temp_log=f"{a} "
                    if math_op == 'add':
                        e = a + b
                        temp_log = f"{temp_log}+ "
                    elif math_op == "sub":
                        e = a - b
                        temp_log = f"{temp_log}- "
                    elif math_op == "mult":
                        e = a * b
                        temp_log = f"{temp_log}* "
                    elif math_op == "mod":
                        e = a % b
                        temp_log = f"{temp_log}% "
                    elif math_op == "div":
                        e = a / b
                        temp_log = f"{temp_log}/ "
                    temp_log = f"{temp_log}{b}={e} your result: {r}"
                    if math.floor(r) != math.floor(e):
                        score = score - error_penalty
                        feedback = f"{feedback}Incorrect calculation: {temp_log}\n"
                if score == 1.0:
                    feedback = f"{feedback}For submission part with id: {part_id} all calculations for math operation: {math_op} were correct. Good Job!\n"
                else:
                    score = math.ceil(score, 0.25)
                    feedback = f"{feedback}For submission part with id: {part_id} not all calculations for math operation: {math_op} were correct.\n"
    except os.error:
        feedback = f"{feedback}An exception occured while parsing the output of your executable, look at the assignment's " \
                    "outputToFile function and ensure that you haven't modified it or the program ran completely.\n"

    print("score: ", score)

    fo.close()
    return score, feedback


if __name__ == '__main__':
    try:
        part_id = os.environ['partId']
        filename = os.environ['filename']
    except Exception as e:
        print_stderr("Please provide the part_id.")
        send_feedback(0.0, "Please provide the part_id.")
    else:
        main(part_id=part_id, filename=filename)
