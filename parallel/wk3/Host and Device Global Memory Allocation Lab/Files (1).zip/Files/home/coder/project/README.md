For this lab, you will need to execute the following commands:

1. make clean build
2. ./cpu_gpu_memory.exe
